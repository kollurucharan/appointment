package com.models;

import java.util.Date;

public class SlotDate {
	Date slotdate;
	int available_slots_count;
	public Date getSlotdate() {
		return slotdate;
	}
	public void setSlotdate(Date slotdate) {
		this.slotdate = slotdate;
	}
	public int getAvailable_slots_count() {
		return available_slots_count;
	}
	public void setAvailable_slots_count(int available_slots_count) {
		this.available_slots_count = available_slots_count;
	}
	
}